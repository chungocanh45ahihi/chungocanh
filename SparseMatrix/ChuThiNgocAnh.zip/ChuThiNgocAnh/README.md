Cài các thư viện sau:
    pip install numpy
    pip istall nltk
    pip install flask

Chạy file : main.py

Cần cho data vào thư mục test để tiến hành input đầu vào
